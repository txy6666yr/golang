package main

/*
该智能合约 表示的是数据分享者调用的链玛
分享者将加密后的数据上传到 ipfs
*/
import (
	"bytes"
	"encoding/binary"
	"encoding/json"
	"fmt"
	"log"
	"math"
	"math/big"
	"math/rand"
	"strconv"
	"unsafe"

	"github.com/hyperledger/fabric-contract-api-go/contractapi"

	"github.com/fentec-project/gofe/data"
	"github.com/fentec-project/gofe/innerprod/fullysec"
	"github.com/fentec-project/gofe/innerprod/simple"
)

// 树的高度
const treeHigth = 6

//声明树
var tree []Node

//定义FE相关变量
//方案1
var l = 1                                                         // 输入向量的长度
var bound = big.NewInt(10)                                        // 输入向量坐标的上界
var modulusLength = 2048                                          // 素模p的位长
var trustedEnt, _ = simple.NewDDHPrecomp(l, modulusLength, bound) //产生信任机构
var msk, mpk, _ = trustedEnt.GenerateMasterKeys()                 //产生主密钥和主公钥
var x = data.NewVector([]*big.Int{big.NewInt(1)})                 // 定义x向量 ={1} 用于加密树结点
var enc = simple.NewDDHFromParams(trustedEnt.Params)              //产生加密器实例
var cipher, err = enc.Encrypt(x, mpk)                             //使用加密器加密主公钥和x向量，产生密文

// 方案2
var numOfClients = 1 //设置客户数量

//var l = 1
//var bound = big.NewInt(1024)
//var modulusLength = 2048 // 素模p的位长
var damgardMulti, _ = fullysec.NewDamgardMultiPrecomp(numOfClients, l, modulusLength, bound) //初始化 damgardMulti实例
var clients = make([]*fullysec.DamgardDecMultiClient, numOfClients)                          //使用make函数定义客户分配变量
var pubKeys = make([]*big.Int, numOfClients)                                                 //使用make 函数定以 公钥 分配变量
var ciphertexts = make([]data.Vector, numOfClients)                                          //定义密文c向量
var secKeys = make([]*fullysec.DamgardDecMultiSecKey, numOfClients)                          //定义私钥

//数据库里面存的都是json格式
//将导入结构合约 api 包并定义我们的 SmartContract。
type SmartContract struct {
	contractapi.Contract
} //定义一个智能合约

//结点属性
type Node struct {
	//存放结点编号
	Num string `json:"Num"`
	//存放关键字对应的TreeCID切片
	TreeCID string `json:"TreeCID"`
	Left    int    `json:"Left"`
	Right   int    `json:"Rigth"`
}

//元数据
type Metadata struct {
	ID           string `json:"ID"`
	DateName     string `json:"dateName"`
	CID          string `json:"CID"`
	EncryptedKey string `json:"encryptedKey"`
	SharerName   string `json:"shareNamer"`
	ShareTime    string `json:"shareTime"`
}

//初始化二叉树
func (s *SmartContract) InitCBT(ctx contractapi.TransactionContextInterface) error {
	//初始化完全二叉树
	// tree := createCBT()
	tree := createCBT()
	//将二叉树 数组元素转为json格式并存入区块链
	for _, treeNode := range tree {
		treeNodeJSON, err := json.Marshal(treeNode)
		if err != nil {
			return err
		}
		//以树的num为键存入
		err = ctx.GetStub().PutState(treeNode.Num, treeNodeJSON)
		if err != nil {
			return fmt.Errorf("failed to put to world state. %v", err)
		} //输出错误

	}
	// 加密树节点
	encTreeNode()
	return nil
}

/*
根据树编号 读取树节点
// ReadTreeNode
*/
func (s *SmartContract) ReadTreeNode(ctx contractapi.TransactionContextInterface, Num string) (*Node, error) {
	treeNodeJSON, err := ctx.GetStub().GetState(Num)
	if err != nil {
		return nil, fmt.Errorf("failed to read from world state: %v", err)
	} //区块链中没有元数据
	if treeNodeJSON == nil {
		return nil, fmt.Errorf("the treeNode %s does not exist", Num)
	}

	//将取出的json格式数据转为 对象
	var treeNode Node
	err = json.Unmarshal(treeNodeJSON, &treeNode)
	if err != nil {
		return nil, err
	}

	return &treeNode, nil
}

/*
根据关键字  读取树节点  需要对树节点进行解密
// ReadTreeNode
*/
func (s *SmartContract) ReadTreeNodeByKeyword(ctx contractapi.TransactionContextInterface, keyword string) (*Node, error) {
	//生成关键字数字
	num := keyWordsNum1(keyword)
	//根据关键字产生{0,1}*
	key := randNum(num)
	//根据{0,1}*找到树节点序号
	// index := findNodeByKey(key, tree)
	index := findNodeByKeyDecByDamgardMult(key)
	strIndex := strconv.Itoa(index)

	treeNodeJSON, err := ctx.GetStub().GetState(strIndex)
	if err != nil {
		return nil, fmt.Errorf("failed to read from world state: %v", err)
	} //区块链中没有元数据
	if treeNodeJSON == nil {
		return nil, fmt.Errorf("the treeNode %s does not exist", strIndex)
	}

	//将取出的json格式数据转为 对象
	var treeNode Node
	err = json.Unmarshal(treeNodeJSON, &treeNode)
	if err != nil {
		return nil, err
	}

	return &treeNode, nil
}

//允许查询分类帐以返回分类帐上的所有共享元数据。
func (s *SmartContract) GetCBT(ctx contractapi.TransactionContextInterface) ([]*Node, error) {
	/*
	   对startKey和endKey进行空字符串的范围查询，对chaincode命名空间中的所有资产进行开放式查询。
	   int(math.Pow(2, treeHigth) - 1)
	*/
	resultsIterator, err := ctx.GetStub().GetStateByRange("0", strconv.Itoa(int(math.Pow(2, treeHigth)-1)))
	if err != nil {
		return nil, err
	}
	// 延迟函数 关闭迭代器
	defer resultsIterator.Close()
	//定义元数据数组
	var tree []*Node
	for resultsIterator.HasNext() {
		queryResponse, err := resultsIterator.Next()
		if err != nil {
			return nil, err
		}

		var treeNode Node
		err = json.Unmarshal(queryResponse.Value, &treeNode)
		if err != nil {
			return nil, err
		}
		//将取出的一个元数据加到数组
		tree = append(tree, &treeNode)
	}

	return tree, nil
}

/*
 更新元数据
 	Num string `json:"Num"`
	//存放关键字对应的TreeCID切片
	TreeCID []string `json:"TreeCID"`
	Left    int      `json:"Left"`
	Right   int      `json:"Rigth"`
*/
func (s *SmartContract) UpdateTree(ctx contractapi.TransactionContextInterface, Num string, TreeCID string, Left int, Right int) error {
	// 用新数据重写原来的数据实现更新
	treeNode := Node{
		Num:     Num,
		TreeCID: TreeCID,
		Left:    Left,
		Right:   Right,
	}

	//将对象转为json格式
	treeNodeJSON, err := json.Marshal(treeNode)
	if err != nil {
		return err
	}
	return ctx.GetStub().PutState(Num, treeNodeJSON)
}

//关键字更新树  明文树
func (s *SmartContract) UpdateTreeByKeyword(ctx contractapi.TransactionContextInterface, keyword string, TreeCID string) error {
	//生成关键字数字
	num := keyWordsNum1(keyword)
	//根据关键字产生{0,1}*
	key := randNum(num)
	//根据{0,1}*找到树节点
	index := findNodeByKey(key, tree)
	strIndex := strconv.Itoa(index)

	// 更新树节点
	treeNode := Node{
		Num:     strIndex,
		TreeCID: TreeCID,
		Left:    0,
		Right:   0,
	}

	//将对象转为json格式
	treeNodeJSON, err := json.Marshal(treeNode)
	if err != nil {
		return err
	}
	return ctx.GetStub().PutState(strIndex, treeNodeJSON)
}

//关键字更新加密树  加密方案1
func (s *SmartContract) UpdateEncTreeByKeyword(ctx contractapi.TransactionContextInterface, keyword string, TreeCID string) error {
	//生成关键字数字
	num := keyWordsNum1(keyword)
	//根据关键字产生{0,1}*
	key := randNum(num)
	//根据{0,1}*找到树节点
	index := findNodeByKeyDec(key)
	strIndex := strconv.Itoa(index)

	// 更新树节点
	treeNode := Node{
		Num:     strIndex,
		TreeCID: TreeCID,
		Left:    0,
		Right:   0,
	}

	//将对象转为json格式
	treeNodeJSON, err := json.Marshal(treeNode)
	if err != nil {
		return err
	}
	return ctx.GetStub().PutState(strIndex, treeNodeJSON)
}

//关键字更新加密树  加密方案2 DamgardMult方案
func (s *SmartContract) UpdateDamgardMultEncTreeByKeyword(ctx contractapi.TransactionContextInterface, keyword string, TreeCID string) error {
	//生成关键字数字
	num := keyWordsNum1(keyword)
	//根据关键字产生{0,1}*
	key := randNum(num)
	//根据{0,1}*找到树节点   解密方案 使用加密方案2
	index := findNodeByKeyDecByDamgardMult(key)
	strIndex := strconv.Itoa(index)

	// 更新树节点
	treeNode := Node{
		Num:     strIndex,
		TreeCID: TreeCID,
		Left:    0,
		Right:   0,
	}

	//将对象转为json格式
	treeNodeJSON, err := json.Marshal(treeNode)
	if err != nil {
		return err
	}
	return ctx.GetStub().PutState(strIndex, treeNodeJSON)
}

//创建完全二叉树 Complete binary tree
func createCBT() []Node {
	//二叉树结点个数
	nodeNum := int(math.Pow(2, treeHigth) - 1)
	//创建tree树 切片并初始化
	var tree []Node
	for i := 0; i < nodeNum; i++ {
		// 定义Node 类型变量，填充所有字段
		treeNode := Node{
			//CID 切片值为结点编号
			// TreeCID: []string{strconv.Itoa(i)},
			TreeCID: strconv.Itoa(i),
			Left:    0,
			Right:   0,
			Num:     strconv.Itoa(i),
		}
		tree = append(tree, treeNode)
	}
	//fmt.Println(tree[1].CID)

	for i := 0; i < len(tree)/2; i++ {
		if (2*i + 1) < len(tree) {
			tree[i].Left = 2*i + 1
		}
		if (2*i + 2) < len(tree) {
			tree[i].Right = 2*i + 2
		}
	}
	//返回切片
	return tree
}

//根据01密钥找到对应二叉树结点   树没有加密
func findNodeByKey(key []int, tree []Node) int {
	//index 表示结点所在位置
	index := 0
	for i := 0; i < len(key); i++ {
		if index < int(math.Pow(2, treeHigth)-1) { //没有越界
			if key[i] == 0 { //左孩子结点
				index = 2*index + 1
			} else { //右孩子结点
				index = 2*index + 2
			}
		} else {
			fmt.Println("key查找二叉树越界")
		}
	}
	return index
}

// 使用 01 密钥找到节点  树加密方案是1
func findNodeByKeyDec(key []int) int {
	//index 表示结点所在位置
	index := 0
	for i := 0; i < len(key); i++ {
		if index < int(math.Pow(2, treeHigth)-1) { //没有越界
			//分别取出 {0,1}序列作为y向量
			y := data.NewVector([]*big.Int{big.NewInt(int64(key[i]))})
			feKey, _ := trustedEnt.DeriveKey(msk, y) //产生y向量的函数密钥
			//生成解密器
			dec := simple.NewDDHFromParams(trustedEnt.Params)
			//解密获得结果
			xy, _ := dec.Decrypt(cipher, feKey, y) //xy类型是指针 var xy *big.Int
			xystr := xy.String()
			xynum, _ := strconv.Atoi(xystr)
			if xynum == 0 { //左孩子结点
				index = 2*index + 1
			} else { //右孩子结点
				index = 2*index + 2
			}
		} else {
			// 输出错误日志
			log.Panicf("key查找二叉树越界")
		}
	}
	return index
}

// 用 key解密节点  方案2
func findNodeByKeyDecByDamgardMult(key []int) int {
	//index 表示结点所在位置
	index := 0
	for i := 0; i < len(key); i++ {
		if index < int(math.Pow(2, treeHigth)-1) { //没有越界
			// xynum := decTreeNode1(key[i])
			//  使用DamgardMulti方案 解密
			xynum := decTreeNodeByDamgardMulti(key[i])
			if xynum == 0 { //左孩子结点
				index = 2*index + 1
			} else { //右孩子结点
				index = 2*index + 2
			}
		} else {
			fmt.Println("key查找二叉树越界")
		}
	}
	return index
}

//解密树节点 根据密文和 key值   测试函数
func decTreeNode1(key int) int {
	clients[0], err = fullysec.NewDamgardDecMultiClient(0, damgardMulti)
	pubKeys[0] = clients[0].ClientPubKey
	// 每个客户端从公钥中生成一个私有部分密钥，并为向量的加密创建自己的秘密密钥
	secKeys := make([]*fullysec.DamgardDecMultiSecKey, numOfClients)
	err = clients[0].SetShare(pubKeys)
	if err != nil {
		fmt.Printf("Error during share generation: %v", err)
	}
	secKeys[0], err = clients[0].GenerateKeys()
	if err != nil {
		fmt.Printf("Error during secret keys generation: %v", err)
	}
	// 每个客户机加密自己的向量x_i
	ciphertexts := make([]data.Vector, numOfClients)
	// 用于检查加密/解密是否正常
	collectedX := make([]data.Vector, numOfClients)
	x := data.NewVector([]*big.Int{big.NewInt(1)}) //x向量是1
	if err != nil {
		fmt.Printf("Error during random vector generation: %v", err)
	}
	collectedX[0] = x
	c, err := clients[0].Encrypt(x, secKeys[0])
	if err != nil {
		fmt.Printf("Error during encryption: %v", err)
	}
	ciphertexts[0] = c
	// 选择一个矩阵表示内积向量y_i的集合
	vecs := make([]data.Vector, 1) // a slice of 1 vectors
	vecs[0] = []*big.Int{big.NewInt(int64(key))}
	y, _ := data.NewMatrix(vecs)
	//fmt.Println("y矩阵是:", y)
	partKeys := make([]*fullysec.DamgardDecMultiDerivedKeyPart, numOfClients)
	partKeys[0], err = clients[0].DeriveKeyShare(secKeys[0], y)
	if err != nil {
		fmt.Printf("Error during derivation of key: %v", err)
	}
	// 模拟解密器
	decryptor := fullysec.NewDamgardDecMultiDec(damgardMulti)
	// Decryptor对该值进行解密
	xy, err := decryptor.Decrypt(ciphertexts, partKeys, y)
	xystr := xy.String()
	xynum, _ := strconv.Atoi(xystr)
	// 返回解密得到的值(向量内积)
	return xynum
}

// 加密解密节点————————————————————————————————————————
//  加密节点——方案2
func encTreeNode() {
	clients[0], err = fullysec.NewDamgardDecMultiClient(0, damgardMulti)
	pubKeys[0] = clients[0].ClientPubKey
	// 每个客户端从公钥中生成一个私有部分密钥，并为向量的加密创建自己的秘密密钥
	// secKeys := make([]*fullysec.DamgardDecMultiSecKey, numOfClients)
	err = clients[0].SetShare(pubKeys)
	if err != nil {
		fmt.Printf("Error during share generation: %v", err)
	}
	secKeys[0], err = clients[0].GenerateKeys()
	if err != nil {
		fmt.Printf("Error during secret keys generation: %v", err)
	}
	// 每个客户机加密自己的向量x_i
	// ciphertexts := make([]data.Vector, numOfClients)
	// 用于检查加密/解密是否正常
	// collectedX := make([]data.Vector, numOfClients)
	// 定义x 向量
	x := data.NewVector([]*big.Int{big.NewInt(1)}) //x向量是1
	if err != nil {
		fmt.Printf("Error during random vector generation: %v", err)
	}
	// collectedX[0] = x
	// 私钥加密
	c, err := clients[0].Encrypt(x, secKeys[0])
	if err != nil {
		fmt.Printf("Error during encryption: %v", err)
	}
	// 密文c 放在密文向量中
	ciphertexts[0] = c
}

// 解密节点—方案2
func decTreeNodeByDamgardMulti(key int) int {
	// 选择一个矩阵表示内积向量y_i的集合
	vecs := make([]data.Vector, 1) // a slice of 1 vectors
	vecs[0] = []*big.Int{big.NewInt(int64(key))}
	y, _ := data.NewMatrix(vecs)
	//fmt.Println("y矩阵是:", y)
	partKeys := make([]*fullysec.DamgardDecMultiDerivedKeyPart, numOfClients)
	partKeys[0], err = clients[0].DeriveKeyShare(secKeys[0], y)
	if err != nil {
		fmt.Printf("Error during derivation of key: %v", err)
	}
	// 模拟解密器
	decryptor := fullysec.NewDamgardDecMultiDec(damgardMulti)
	// Decryptor对该值进行解密
	xy, _ := decryptor.Decrypt(ciphertexts, partKeys, y)
	xystr := xy.String()
	xynum, _ := strconv.Atoi(xystr)
	// 返回解密得到的值(向量内积)
	return xynum
}

//产生随机序列密钥
func randNum(seed int64) []int {
	//  设置种子，只需一次
	//  如果种子参数一样，每次运行程序产生的随机数都一样
	rand.Seed(seed)
	//密钥数组 存放对应的0 1串
	var key []int
	//  产生随机数
	for i := 0; i < treeHigth-1; i++ {
		key = append(key, rand.Intn(2))
		//fmt.Print(key[i], " ") //输出 0 1串
	}
	return key
}

//根据关键字生成对应int数据
func keyWordsNum(keyword string) int64 {
	//将关键字转为 byte数组
	byteArray := stringTobyteSlice(keyword)
	//将byte数组转为int数字
	length := float64(len(byteArray)) - 1
	var x float64
	for _, value := range byteArray {
		tmp := math.Pow(10, length)
		x = x + (float64(value)-48)*tmp
		length--
	}
	//fmt.Println(int64(x)) //输出
	return int64(x)
}
func keyWordsNum1(keyword string) int64 {
	b := []byte(keyword)
	bytesBuffer := bytes.NewBuffer(b)

	var x int64
	binary.Read(bytesBuffer, binary.BigEndian, &x)
	return x
}

//类型转换——————————————————————————————————————
// string转为byte切片
func stringTobyteSlice(s string) []byte {
	tmp1 := (*[2]uintptr)(unsafe.Pointer(&s))
	tmp2 := [3]uintptr{tmp1[0], tmp1[1], tmp1[1]}
	return *(*[]byte)(unsafe.Pointer(&tmp2))
}

//byte切片转为string
func byteSliceToString(bytes []byte) string {
	return *(*string)(unsafe.Pointer(&bytes))
}

//测试使用————————————————————————————
//设置index 对应结点信息
func setNode(index int, node Node, tree []Node) {
	tree[index].TreeCID = node.TreeCID
	tree[index].Num = node.Num
	tree[index].Left = node.Left
	tree[index].Right = node.Right
}

//遍历key密钥
func printKey(key []int) {

	fmt.Print("密钥序列是:")
	for i := 0; i < len(key); i++ {
		fmt.Print(key[i], " ")
	}
	fmt.Println()
}

//元数据部分————————————————————————————————————————————————
//实现 初始化元数据，用一些初始数据填充分类帐的函数

func (s *SmartContract) InitMetadata(ctx contractapi.TransactionContextInterface) error {
	//初始化大豆和小麦元数据
	metadatas := []Metadata{
		{ID: "data1", DateName: "soybean", CID: "QmP7FyZCMRrg9fVimkJcuQTKMNiYomLBus159GvTMzwGH9",
			EncryptedKey: "d1a5d1sa5", SharerName: "南京农业大学", ShareTime: "2022/04/12"},
		{ID: "data2", DateName: "wheat", CID: "QmWfARAbR9J7j25nrmP2JsjW4qePTw7LBQGVt3U3Bmy61R",
			EncryptedKey: "dad48sa9dfas", SharerName: "南京农业大学", ShareTime: "2022/04/12"},
	} //创建对象数组 名称是metadatas  类型是Metadata

	//将Metadata 数组元素转为json格式并存入区块链
	for _, metadata := range metadatas {
		metadataJSON, err := json.Marshal(metadata)
		if err != nil {
			return err
		}
		//*****************修改******************
		cck, _ := ctx.GetStub().CreateCompositeKey("CID-id", []string{metadata.CID, metadata.ID})
		err = ctx.GetStub().PutState(cck, metadataJSON)
		if err != nil {
			return fmt.Errorf("failed to put to world state. %v", err)
		} //输出错误

		err = ctx.GetStub().PutState(metadata.ID, metadataJSON)
		if err != nil {
			return fmt.Errorf("failed to put to world state. %v", err)
		} //输出错误

	}

	return nil
}

/*
检查元数据是否存在
以ID作为标识，查看是否存在元数据
*/
func (s *SmartContract) MetadataExists(ctx contractapi.TransactionContextInterface, id string) (bool, error) {
	metadataJSON, err := ctx.GetStub().GetState(id)
	if err != nil {
		return false, fmt.Errorf("failed to read from world state: %v", err)
	}

	return metadataJSON != nil, nil
}

/*
读取元数据
// ReadMetatdata返回存储在给定id的world状态下的资产。
*/
func (s *SmartContract) ReadMetatdata(ctx contractapi.TransactionContextInterface, id string) (*Metadata, error) {
	metadataJSON, err := ctx.GetStub().GetState(id)
	if err != nil {
		return nil, fmt.Errorf("failed to read from world state: %v", err)
	} //区块链中没有元数据
	if metadataJSON == nil {
		return nil, fmt.Errorf("the metadata %s does not exist", id)
	}

	//将取出的json格式数据转为 对象
	var metadata Metadata
	err = json.Unmarshal(metadataJSON, &metadata)
	if err != nil {
		return nil, err
	}

	return &metadata, nil
}

/*
读取元数据
// ReadMetatdataByCID返回存储在给定CID的world状态下的资产。
*/
func (s *SmartContract) ReadMetatdataByCID(ctx contractapi.TransactionContextInterface, CID string) ([]*Metadata, error) {
	//采用组合键查询  第一个参数表示组合键名称   第二个参数为与组合键前缀匹配的字符串  注意不能是后缀匹配
	//  []string{} 切片为空表示的是返回所有的     | id 作为主键  CID作为组合键的前缀
	resultsIterator, err := ctx.GetStub().GetStateByPartialCompositeKey("CID-id", []string{CID})
	if err != nil {
		return nil, err
	}
	defer resultsIterator.Close() //函数结束时调用
	//定义元数据切片
	var metadatas []*Metadata
	for resultsIterator.HasNext() {
		queryResponse, err := resultsIterator.Next()
		if err != nil {
			return nil, err
		}

		var metadata Metadata
		err = json.Unmarshal(queryResponse.Value, &metadata)
		if err != nil {
			return nil, err
		}
		//将取出的一个元数据加到数组
		metadatas = append(metadatas, &metadata)
	}

	return metadatas, nil
}

//创建元数据
func (s *SmartContract) CreateMetadata(ctx contractapi.TransactionContextInterface, id string, dataName string, CID string, encryptedKey string, sharerName string, shareTime string) error {
	exists, err := s.MetadataExists(ctx, id)
	if err != nil {
		return err
	}
	if exists {
		return fmt.Errorf("the metadata %s already exists", id)
	} //已经存在不能创建

	metadata := Metadata{
		ID:           id,
		DateName:     dataName,
		CID:          CID,
		EncryptedKey: encryptedKey,
		SharerName:   sharerName,
		ShareTime:    shareTime,
	}
	metadataJSON, err := json.Marshal(metadata)
	if err != nil {
		return err
	}
	//*****************修改******************

	cck, _ := ctx.GetStub().CreateCompositeKey("CID-id", []string{metadata.CID, metadata.ID})
	err = ctx.GetStub().PutState(cck, metadataJSON)
	if err != nil {
		return fmt.Errorf("failed to put to world state. %v", err)
	} //输出错误

	return ctx.GetStub().PutState(id, metadataJSON)
}

/*
 更新元数据
*/
func (s *SmartContract) UpdateMetadata(ctx contractapi.TransactionContextInterface, id string, dataName string, CID string, encryptedKey string, sharerName string, shareTime string) error {
	exists, err := s.MetadataExists(ctx, id)
	if err != nil {
		return err
	}
	if !exists {
		return fmt.Errorf("the metadata %s does not exist", id)
	} //元数据不存在

	// 用新数据重写原来的数据实现更新
	metadata := Metadata{
		ID:           id,
		DateName:     dataName,
		CID:          CID,
		EncryptedKey: encryptedKey,
		SharerName:   sharerName,
		ShareTime:    shareTime,
	}

	//将对象转为json格式
	metadataJSON, err := json.Marshal(metadata)
	if err != nil {
		return err
	}
	//*****************修改******************

	cck, _ := ctx.GetStub().CreateCompositeKey("CID-id", []string{metadata.CID, metadata.ID})
	err = ctx.GetStub().PutState(cck, metadataJSON)
	if err != nil {
		return fmt.Errorf("failed to put to world state. %v", err)
	} //输出错误

	return ctx.GetStub().PutState(id, metadataJSON)
}

/*
 删除元数据
 根据id标识 原数据
*/
func (s *SmartContract) DeleteMetadata(ctx contractapi.TransactionContextInterface, id string) error {
	exists, err := s.MetadataExists(ctx, id)
	if err != nil {
		return err
	}
	if !exists {
		return fmt.Errorf("the metadata %s does not exist", id)
	}

	//根据 键值删除元数据
	return ctx.GetStub().DelState(id)
}

/*
 删除元数据
 根据复合键删除
*/
func (s *SmartContract) DeleteMetadataByCCK(ctx contractapi.TransactionContextInterface, CID string, id string) error {
	exists, err := s.MetadataExists(ctx, id)
	if err != nil {
		return err
	}
	if !exists {
		return fmt.Errorf("the metadata %s does not exist", id)
	}
	cck, _ := ctx.GetStub().CreateCompositeKey("CID-id", []string{CID, id})
	err = ctx.GetStub().DelState(cck)
	if err != nil {
		return fmt.Errorf("failed to put to world state. %v", err)
	} //输出错误

	//根据 键值删除元数据
	return ctx.GetStub().DelState(id)
}

//允许查询分类帐以返回分类帐上的所有共享元数据。   不使用复合键 直接"" ,""会报错 要指定范围
func (s *SmartContract) GetAllMetadataByCompositeKey(ctx contractapi.TransactionContextInterface) ([]*Metadata, error) {
	//采用组合键查询  第一个参数表示组合键名称   第二个参数为与组合键前缀匹配的字符串  注意不能是后缀匹配
	//  []string{} 切片为空表示的是返回所有的     | id 作为主键  CID作为组合键的前缀
	resultsIterator, err := ctx.GetStub().GetStateByPartialCompositeKey("CID-id", []string{})
	if err != nil {
		return nil, err
	}
	defer resultsIterator.Close() //函数结束时调用
	//定义元数据切片
	var metadatas []*Metadata
	for resultsIterator.HasNext() {
		queryResponse, err := resultsIterator.Next()
		if err != nil {
			return nil, err
		}

		var metadata Metadata
		err = json.Unmarshal(queryResponse.Value, &metadata)
		if err != nil {
			return nil, err
		}
		//将取出的一个元数据加到数组
		metadatas = append(metadatas, &metadata)
	}

	return metadatas, nil
}

//主函数
func main() {
	smartChaincode, err := contractapi.NewChaincode(&SmartContract{})
	if err != nil {
		log.Panicf("Error creating smart chaincode: %v", err)
	}

	if err := smartChaincode.Start(); err != nil {
		log.Panicf("Error starting smart chaincode: %v", err)
	}
}
