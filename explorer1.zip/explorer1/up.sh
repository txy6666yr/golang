#!/bin/bash
sudo rm -rf organizations
cp -r ~/go/src/github.com/hyperledger/fabric-samples/test-network/organizations/ .
docker-compose up -d
docker ps -a
