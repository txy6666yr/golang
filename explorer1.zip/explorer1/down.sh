#!/bin/bash
# 关闭区块链浏览器
docker-compose down -v
docker ps -a
