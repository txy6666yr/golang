#启动浏览器（启动测试网络后）
#每次重新拉取 test-network 文件夹
sudo rm -rf organizations
cp -r ../fabric-samples/test-network/organizations/ .

docker-compose up -d
#关闭浏览器
docker-compose down -v
