#!/bin/bash
rm -rf wallet/
rm -rf keystore/
