#!/bin/bash
cd ~/go/src/github.com/hyperledger/fabric-samples/test-network
./network.sh down
docker ps -a
