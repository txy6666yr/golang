/*
Copyright 2020 IBM All Rights Reserved.

SPDX-License-Identifier: Apache-2.0
*/

package main

// 依赖
import (
	"fmt"
	"io/ioutil"
	"log"
	"os"
	"path/filepath"

	"github.com/hyperledger/fabric-sdk-go/pkg/core/config"
	"github.com/hyperledger/fabric-sdk-go/pkg/gateway"
)

func main() {
	log.Println("============ application-golang starts ============")
	// 设置环境
	err := os.Setenv("DISCOVERY_AS_LOCALHOST", "true")
	if err != nil {
		log.Fatalf("Error setting DISCOVERY_AS_LOCALHOST environemnt variable: %v", err)
		log.Fatalf("设置DISCOVERY_AS_LOCALHOST环境错误: %v", err)
	}
	// 创建钱包
	wallet, err := gateway.NewFileSystemWallet("wallet")
	if err != nil {
		log.Fatalf("Failed to create wallet: %v", err)
		log.Fatalf("创建钱包失败: %v", err)
	}
	// 钱包中appUser 不存在
	if !wallet.Exists("appUser") {
		err = populateWallet(wallet)
		if err != nil {
			log.Fatalf("Failed to populate wallet contents: %v", err)
			log.Fatalf("填充钱包失败:%v", err)
		}
	}
	// 设置配置文件路径
	ccpPath := filepath.Join(
		"..",
		"..",
		"test-network",
		"organizations",
		"peerOrganizations",
		"org1.example.com",
		"connection-org1.yaml",
	)
	// 设置网关 连接
	gw, err := gateway.Connect(
		gateway.WithConfig(config.FromFile(filepath.Clean(ccpPath))),
		gateway.WithIdentity(wallet, "appUser"),
	)
	// 连接网关失败
	if err != nil {
		log.Fatalf("Failed to connect to gateway: %v", err)
		log.Fatalf("连接网关失败%v", err)
	}
	// 延迟函数  函数结束后关闭网关
	defer gw.Close()
	// 通过网关获取网络 ，参数是通道名称
	network, err := gw.GetNetwork("mychannel")
	if err != nil {
		log.Fatalf("Failed to get network: %v", err)
	}
	//获取智能合约  参数是：链码名称
	contract := network.GetContract("basic2")
	// var result []byte
	//——————————————————————————————————————————————————————————
	var n int
	for {
		log.Println("———————————————菜单———————————————")
		log.Println("0.退出")
		log.Println("1.初始化元数据信息 InitMetadata")
		log.Println("2.读取元数据信息 ReadMetatdata")
		log.Println("3.创建元数据信息 CreateMetadata")
		log.Println("4.复合键返回所有元数据信息 GetAllMetadataByCompositeKey")
		log.Println("5.复合键删除元数据信息 DeleteMetadataByCCK")
		log.Println("6.查看元数据是否存在 MetadataExists")
		log.Println("7.更新元数据信息 UpdateMetadata")
		log.Println("8.初始化完全二叉树 InitCBT")
		log.Println("9.根据节点编号读取节点信息 ReadTreeNode")
		log.Println("10.根据关键字读取节点信息 ReadTreeNodeByKeyword")
		log.Println("11.返回完全二叉树信息 GetCBT")
		log.Println("12.根据关键字更新完全二叉树信息 UpdateDamgardMultEncTreeByKeyword")
		log.Println("请输入序号选择执行:")
		fmt.Scanln(&n)
		switch n {
		case 0:
			return
		case 1:
			InitMetadata(contract)
		case 2:
			ReadMetatdata(contract)
		case 3:
			CreateMetadata(contract)
		case 4:
			GetAllMetadataByCompositeKey(contract)
		case 5:
			DeleteMetadataByCCK(contract)
		case 6:
			MetadataExists(contract)
		case 7:
			UpdateMetadata(contract)
		case 8:
			InitCBT(contract)
		case 9:
			ReadTreeNode(contract)
		case 10:
			ReadTreeNodeByKeyword(contract)
		case 11:
			GetCBT(contract)
		case 12:
			UpdateDamgardMultEncTreeByKeyword(contract)
		default:
			log.Panicln("输入有误，请重新输入.")
		}
	}
	//——————————————————————————————————————————————————————————
	/*
		log.Println("--> 评估事务：读取 data 1元数据的数据")
		result, err = contract.EvaluateTransaction("ReadMetatdata", "data1")
		if err != nil {
			log.Fatalf("Failed to evaluate transaction: %v", err)
			log.Fatalf("评估事务失败:%v", err)
		}
		log.Println(string(result))

		log.Println("--> 评估事务：读取 data 2元数据的数据")
		result, err = contract.EvaluateTransaction("ReadMetatdata", "data2")
		if err != nil {
			log.Fatalf("Failed to evaluate transaction: %v", err)
			log.Fatalf("评估事务失败:%v", err)
		}
		log.Println(string(result))

		log.Println("--> 提交事物: 创建元数据 data3")
		result, err = contract.SubmitTransaction("CreateMetadata", "data3", "菊花", "QmUCRiPNW4j1grWqN3QfDTxwy7fEuPBVDpv1Zaxm3w6ZSK", "sd641d6sf", "Tom", "2022/04/17")
		if err != nil {
			log.Fatalf("Failed to Submit transaction: %v", err)
			log.Fatalf("提交事务失败:%v", err)
		}
		log.Println(string(result))
	*/
	/*
		log.Println("--> 评估事务: 复合键查询元数据，函数返回账本上元数据")
		result, err = contract.EvaluateTransaction("GetAllMetadataByCompositeKey")
		if err != nil {
			log.Fatalf("Failed to evaluate transaction: %v\n", err)
			log.Fatalf("评价事务失败: %v\n", err)
		}
		log.Println(string(result))
	*/

	/*
		log.Println("--> Evaluate Transaction: AssetExists, function returns 'true' if an asset with given assetID exist")
		result, err = contract.EvaluateTransaction("AssetExists", "asset1")
		if err != nil {
			log.Fatalf("Failed to evaluate transaction: %v\n", err)
		}
		log.Println(string(result))
	*/
	/*
		log.Println("--> 提交事务: 删除 复合键QmUCRiPNW4j1grWqN3QfDTxwy7fEuPBVDpv1Zaxm3w6ZSK data3 的元数据")
		result, err = contract.SubmitTransaction("DeleteMetadataByCCK", "QmUCRiPNW4j1grWqN3QfDTxwy7fEuPBVDpv1Zaxm3w6ZSK", "data3")
		if err != nil {
			log.Fatalf("Failed to Submit transaction: %v", err)
			log.Fatalf("提交事务失败%v", err)
		}
		log.Println(string(result))

		log.Println("--> 评估事务: 复合键查询元数据，函数返回账本上元数据")
		result, err = contract.EvaluateTransaction("GetAllMetadataByCompositeKey")
		if err != nil {
			log.Fatalf("Failed to evaluate transaction: %v\n", err)
			log.Fatalf("评价事务失败: %v\n", err)
		}
		log.Println(string(result))*/
}

// 调用初始化元数据合约 参数是智能合约
func InitMetadata(contract *gateway.Contract) {
	log.Println("--> 提交事务：初始化元数据，函数初始化元数据存入账本(初始数据有两条，仅第一次运行")
	result, err := contract.SubmitTransaction("InitMetadata")
	if err != nil {
		log.Fatalf("Failed to Submit transaction: %v", err)
		log.Fatalf("提交事务失败: %v", err)
	}
	// 输出结果
	log.Println(string(result))
}

// 读取元数据
func ReadMetatdata(contract *gateway.Contract) {
	log.Println("--> 评估事务：读取元数据的数据")
	var nameId string
	log.Println("--> 请输入读取id")
	fmt.Scanln(&nameId)
	result, err := contract.EvaluateTransaction("ReadMetatdata", nameId)
	if err != nil {
		log.Fatalf("Failed to evaluate transaction: %v", err)
		log.Fatalf("评估事务失败:%v", err)
	}
	log.Println(string(result))
}

// 创建元数据
func CreateMetadata(contract *gateway.Contract) {
	// 定义变量
	var id, dataName, CID, EncryptedKey, SharerName, ShareTime string
	log.Println("--> 提交事物: 创建元数据，请依次输入元数据参数:id dataName CID EncryptedKey SharerName ShareTime")
	// 输入参数
	fmt.Scanln(&id, &dataName, &CID, &EncryptedKey, &SharerName, &ShareTime)
	result, err := contract.SubmitTransaction("CreateMetadata", id, dataName, CID, EncryptedKey, SharerName, ShareTime)
	if err != nil {
		log.Fatalf("Failed to Submit transaction: %v", err)
		log.Fatalf("提交事务失败:%v", err)
	}
	log.Println(string(result))
}

// 更新元数据
func UpdateMetadata(contract *gateway.Contract) {
	// 定义变量
	var id, dataName, CID, EncryptedKey, SharerName, ShareTime string
	log.Println("--> 提交事物: 更新元数据，请依次输入元数据参数:id dataName CID EncryptedKey SharerName ShareTime")
	// 输入参数
	fmt.Scanln(&id, &dataName, &CID, &EncryptedKey, &SharerName, &ShareTime)
	result, err := contract.SubmitTransaction("UpdateMetadata", id, dataName, CID, EncryptedKey, SharerName, ShareTime)
	if err != nil {
		log.Fatalf("Failed to Submit transaction: %v", err)
		log.Fatalf("提交事务失败:%v", err)
	}
	log.Println(string(result))
}

// 复合键 返回账本数据
func GetAllMetadataByCompositeKey(contract *gateway.Contract) {
	log.Println("--> 评估事务: 复合键查询元数据，函数返回账本上元数据")
	result, err := contract.EvaluateTransaction("GetAllMetadataByCompositeKey")
	if err != nil {
		log.Fatalf("Failed to evaluate transaction: %v\n", err)
		log.Fatalf("评价事务失败: %v\n", err)
	}
	log.Println(string(result))
}

// 复合键删除元数据
func DeleteMetadataByCCK(contract *gateway.Contract) {
	var CID, id string
	log.Println("--> 提交事务: 删除 复合键对应的元数据，请输入复合键CID-ID(空格分开):")
	fmt.Scanln(&CID, &id)
	result, err := contract.SubmitTransaction("DeleteMetadataByCCK", CID, id)
	if err != nil {
		log.Fatalf("Failed to Submit transaction: %v", err)
		log.Fatalf("提交事务失败%v", err)
	}
	log.Println(string(result))
}

// 查看元数据是否存在
func MetadataExists(contract *gateway.Contract) {
	var id string
	log.Println("--> 评估事务: 查看元数据是否存在, 请输入元数据对应ID:")
	fmt.Scanln(&id)
	result, err := contract.EvaluateTransaction("MetadataExists", id)
	if err != nil {
		log.Fatalf("Failed to evaluate transaction: %v\n", err)
		log.Fatalf("评价事务失败: %v\n", err)
	}
	log.Println(string(result))
}

// 初始化完全二叉树
func InitCBT(contract *gateway.Contract) {
	log.Println("--> 提交事务：初始化完全二叉树存入账本(仅第一次运行)")
	result, err := contract.SubmitTransaction("InitCBT")
	if err != nil {
		log.Fatalf("Failed to Submit transaction: %v", err)
		log.Fatalf("提交事务失败: %v", err)
	}
	// 输出结果
	log.Println(string(result))
}

// 根据节点编号读取树节点信息
func ReadTreeNode(contract *gateway.Contract) {
	log.Println("--> 评估事务：读取完全二叉树节点信息")
	var num string
	log.Println("--> 请输入树节点编号")
	fmt.Scanln(&num)
	result, err := contract.EvaluateTransaction("ReadTreeNode", num)
	if err != nil {
		log.Fatalf("Failed to evaluate transaction: %v", err)
		log.Fatalf("评估事务失败:%v", err)
	}
	log.Println(string(result))
}

// 根据关键字 读取树节点信息  (需要解密)
func ReadTreeNodeByKeyword(contract *gateway.Contract) {
	log.Println("--> 评估事务：读取完全二叉树节点信息")
	var keyword string
	log.Println("--> 请输入关键字:")
	fmt.Scanln(&keyword)
	result, err := contract.EvaluateTransaction("ReadTreeNodeByKeyword", keyword)
	if err != nil {
		log.Fatalf("Failed to evaluate transaction: %v", err)
		log.Fatalf("评估事务失败:%v", err)
	}
	log.Println(string(result))
}

// 返回完全二叉树信息
func GetCBT(contract *gateway.Contract) {
	log.Println("--> 评估事务: 返回区块链上完全二叉树信息")
	result, err := contract.EvaluateTransaction("GetCBT")
	if err != nil {
		log.Fatalf("Failed to evaluate transaction: %v\n", err)
		log.Fatalf("评价事务失败: %v\n", err)
	}
	log.Println(string(result))
}

// 更新完全二叉树信息
func UpdateDamgardMultEncTreeByKeyword(contract *gateway.Contract) {
	// 定义变量
	var keyword, CID string
	log.Println("--> 提交事物: 更新完全二叉树，请依次输入元数据参数: 关键字 CID")
	// 输入参数
	fmt.Scanln(&keyword, &CID)
	result, err := contract.SubmitTransaction("UpdateDamgardMultEncTreeByKeyword", keyword, CID)
	if err != nil {
		log.Fatalf("Failed to Submit transaction: %v", err)
		log.Fatalf("提交事务失败:%v", err)
	}
	log.Println(string(result))
}

// 填充钱包 参数是钱包
func populateWallet(wallet *gateway.Wallet) error {
	log.Println("============ Populating wallet ============")
	// 证书路径
	credPath := filepath.Join(
		"..",
		"..",
		"test-network",
		"organizations",
		"peerOrganizations",
		"org1.example.com",
		"users",
		"User1@org1.example.com",
		"msp",
	)
	// 这是CA 方式启动区块链网络时的路径
	// certPath := filepath.Join(credPath, "signcerts", "cert.pem")
	// 这是普通启动时区块链网络的路径
	certPath := filepath.Join(credPath, "signcerts", "User1@org1.example.com-cert.pem")
	// read the certificate pem  读取证书pem
	cert, err := ioutil.ReadFile(filepath.Clean(certPath))
	if err != nil {
		return err
	}
	// 获取密钥目录
	keyDir := filepath.Join(credPath, "keystore")
	// 在这个目录中有一个包含私钥的文件
	files, err := ioutil.ReadDir(keyDir)
	if err != nil {
		return err
	}
	if len(files) != 1 {
		return fmt.Errorf("keystore folder should have contain one file Keystore文件夹应该包含一个文件")
	}
	keyPath := filepath.Join(keyDir, files[0].Name())
	// 从keypath 获取密钥
	key, err := ioutil.ReadFile(filepath.Clean(keyPath))
	if err != nil {
		return err
	}
	// 根据密钥和证书获取身份
	identity := gateway.NewX509Identity("Org1MSP", string(cert), string(key))

	return wallet.Put("appUser", identity)
}
