#!/bin/bash
cd ~/go/src/github.com/hyperledger/fabric-samples/test-network
./network.sh down
./network.sh up createChannel
#./network.sh up createChannel -c mychannel -ca
# 部署链码
./network.sh deployCC -ccn basic2 -ccp ../chaincode/tree/ -ccl go
cd ~/go/src/github.com/hyperledger/fabric-samples/asset-transfer-basic/application-go-sharer
go mod tidy
go mod vendor
go run sharer.go
